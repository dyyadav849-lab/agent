-- Initialize TI-Bot Memory Database
-- This script creates the necessary tables and indexes for the memory system

-- Create database if it doesn't exist (this will be run by docker-entrypoint-initdb.d)
CREATE DATABASE IF NOT EXISTS tibot_memory;
CREATE DATABASE IF NOT EXISTS tibot_test;

-- Connect to the main database
\c tibot_memory;

-- Create extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "vector";

-- Memory Sessions Table
CREATE TABLE IF NOT EXISTS memory_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id VARCHAR(255) UNIQUE NOT NULL,
    user_id VARCHAR(255),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'
);

-- Long-term Memory Table
CREATE TABLE IF NOT EXISTS long_term_memory (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    content_type VARCHAR(100) NOT NULL,
    importance_score FLOAT DEFAULT 0.0,
    access_count INTEGER DEFAULT 0,
    embedding vector(1536), -- OpenAI embedding size
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    last_accessed TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}',
    FOREIGN KEY (session_id) REFERENCES memory_sessions(session_id) ON DELETE CASCADE
);

-- Memory Chunks Table (for semantic chunking)
CREATE TABLE IF NOT EXISTS memory_chunks (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    parent_memory_id UUID NOT NULL,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    chunk_type VARCHAR(100) NOT NULL,
    embedding vector(1536),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}',
    FOREIGN KEY (parent_memory_id) REFERENCES long_term_memory(id) ON DELETE CASCADE
);

-- Memory Associations Table (for connecting related memories)
CREATE TABLE IF NOT EXISTS memory_associations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    source_memory_id UUID NOT NULL,
    target_memory_id UUID NOT NULL,
    association_type VARCHAR(100) NOT NULL,
    strength FLOAT DEFAULT 1.0,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (source_memory_id) REFERENCES long_term_memory(id) ON DELETE CASCADE,
    FOREIGN KEY (target_memory_id) REFERENCES long_term_memory(id) ON DELETE CASCADE
);

-- Performance Metrics Table
CREATE TABLE IF NOT EXISTS performance_metrics (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    metric_name VARCHAR(255) NOT NULL,
    metric_value FLOAT NOT NULL,
    metric_type VARCHAR(100) NOT NULL,
    session_id VARCHAR(255),
    timestamp TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
    metadata JSONB DEFAULT '{}'
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_memory_sessions_session_id ON memory_sessions(session_id);
CREATE INDEX IF NOT EXISTS idx_memory_sessions_user_id ON memory_sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_memory_sessions_created_at ON memory_sessions(created_at);

CREATE INDEX IF NOT EXISTS idx_long_term_memory_session_id ON long_term_memory(session_id);
CREATE INDEX IF NOT EXISTS idx_long_term_memory_content_type ON long_term_memory(content_type);
CREATE INDEX IF NOT EXISTS idx_long_term_memory_importance ON long_term_memory(importance_score DESC);
CREATE INDEX IF NOT EXISTS idx_long_term_memory_created_at ON long_term_memory(created_at);
CREATE INDEX IF NOT EXISTS idx_long_term_memory_embedding ON long_term_memory USING ivfflat (embedding vector_cosine_ops);

CREATE INDEX IF NOT EXISTS idx_memory_chunks_parent_id ON memory_chunks(parent_memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_chunks_type ON memory_chunks(chunk_type);
CREATE INDEX IF NOT EXISTS idx_memory_chunks_embedding ON memory_chunks USING ivfflat (embedding vector_cosine_ops);

CREATE INDEX IF NOT EXISTS idx_memory_associations_source ON memory_associations(source_memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_associations_target ON memory_associations(target_memory_id);
CREATE INDEX IF NOT EXISTS idx_memory_associations_type ON memory_associations(association_type);

CREATE INDEX IF NOT EXISTS idx_performance_metrics_name ON performance_metrics(metric_name);
CREATE INDEX IF NOT EXISTS idx_performance_metrics_type ON performance_metrics(metric_type);
CREATE INDEX IF NOT EXISTS idx_performance_metrics_timestamp ON performance_metrics(timestamp);

-- Create a trigger to update the updated_at column
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = CURRENT_TIMESTAMP;
    RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_memory_sessions_updated_at 
    BEFORE UPDATE ON memory_sessions 
    FOR EACH ROW EXECUTE PROCEDURE update_updated_at_column();

-- Create a function to calculate memory importance
CREATE OR REPLACE FUNCTION calculate_memory_importance(
    access_count INTEGER,
    age_hours FLOAT,
    content_length INTEGER
) RETURNS FLOAT AS $$
BEGIN
    -- Simple importance calculation: access frequency, recency, and content richness
    RETURN (access_count * 0.4) + (1.0 / (age_hours / 24.0 + 1.0) * 0.4) + (LEAST(content_length / 1000.0, 1.0) * 0.2);
END;
$$ LANGUAGE plpgsql;
