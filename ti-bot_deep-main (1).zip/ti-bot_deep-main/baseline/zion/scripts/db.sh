#!/usr/bin/env bash

exec python -u "scripts/db.py" "$@"
