Zion is the LLM Agent framework maintained by Foundation GATE team, which is the LLM integration provider for various use cases Including TI Support Bot's Level Zero Support, TI Support Bot DM Bot, Audodoc.


Checkout the [RFC: TI Bot Agent](https://wiki.grab.com/display/SWAT/RFC%3A+TI+Bot+Agent) for more details.
