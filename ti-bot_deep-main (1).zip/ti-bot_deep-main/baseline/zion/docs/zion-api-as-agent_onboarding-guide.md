Procedures to obtain the API Key for Zion Agent API

1. Navigate to [#ask-tibot](https://grab.enterprise.slack.com/archives/C04FE6H2NG3) channel, and choose the **New Zion API Agent** workflow and complete the form.

2. Wait for @oncall-gate to verify the use cases and confirming the namespace is valid to use

3. @oncall-gate to provides the wrapped Agent API keys to the applicant via Slack DM.



SLA: 2 working days
