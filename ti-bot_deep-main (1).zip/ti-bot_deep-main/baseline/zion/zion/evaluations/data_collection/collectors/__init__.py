"""Collectors package for evaluation data pipeline."""
