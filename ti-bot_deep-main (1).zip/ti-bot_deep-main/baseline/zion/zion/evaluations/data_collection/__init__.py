"""Data collection package for evaluation data pipeline."""
