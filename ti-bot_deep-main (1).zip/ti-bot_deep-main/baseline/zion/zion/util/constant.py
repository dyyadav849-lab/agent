# document metadata
DocumentTitle = "document_title"
DocumentUri = "document_uri"

K8S_INDEX = "k8s-*"
GRAB_INDEX = "grab-*"
