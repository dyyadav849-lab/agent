from zion.util.log.queue_listener import configure_log_listener

configure_log_listener(console=True)
