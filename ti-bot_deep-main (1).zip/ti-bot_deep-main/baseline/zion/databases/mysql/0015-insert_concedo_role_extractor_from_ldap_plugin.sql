-- +migrate Up
INSERT INTO `zion`.`agent_plugin` (
`schema_version`,
`name_for_model`,
`name_for_human`,
`description_for_model`,
`description_for_human`,
`type`,
`api`,
`is_moved`
) VALUES (
    '1.0',
    'concedo_role_extractor_from_ldap',
    'Concedo Role Extractor From LDAP',
    ' ',
    'Used to get obtain all concedo roles to gain access to a ldap group, given a list of ldap group. ',
    'common',
    '{
        "access_control": {
            "agents": {
                "ti-bot-dm": {},
                "ti-bot-level-zero": {}
            }
        }
    }',
    '0'
);
-- +migrate Down
DELETE FROM
  `zion`.`agent_plugin`
WHERE
  `name_for_model` = 'concedo_role_extractor_from_ldap';
