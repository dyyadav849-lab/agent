ACTIVE_STATUS = "active"
INACTIVE_STATUS = "inactive"

FILETYPE_UPLOAD_FILE = "uploaded_file"
FILETYPE_FILE_CONTENT = "file_content"
