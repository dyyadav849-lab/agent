open_api_config = {
    201: {"description": "Item retrieved successfully"},
    401: {"description": "Unauthorized"},
}
