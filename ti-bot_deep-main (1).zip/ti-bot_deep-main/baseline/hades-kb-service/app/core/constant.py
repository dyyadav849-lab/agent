from app.core.config import app_config

query_limit = app_config.knowledge_base_default_query_limit
