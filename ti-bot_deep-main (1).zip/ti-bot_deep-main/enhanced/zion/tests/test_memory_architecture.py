"""
Comprehensive Test Suite for Memory-Enhanced Architecture
========================================================

Tests for the 3-layer memory system including:
- Working Memory (LRU Cache)
- Short-Term Memory (Redis)
- Long-Term Memory (PostgreSQL)
- Memory Orchestrator
"""

import pytest
import asyncio
from unittest.mock import Mock, AsyncMock, patch
from datetime import datetime, timedelta
from typing import Dict, List, Any

# Import memory components
try:
    from zion.memory.working_memory import WorkingMemory, ConversationContext
    from zion.memory.short_term import ShortTermMemory
    from zion.memory.long_term import LongTermMemory
    from zion.memory.memory_orchestrator import MemoryOrchestrator
    from zion.agent.memory_enhanced_zion_agent import MemoryEnhancedZionAgent
except ImportError as e:
    pytest.skip(f"Memory modules not available: {e}", allow_module_level=True)


class TestWorkingMemory:
    """Test Working Memory (LRU Cache) functionality"""
    
    def setup_method(self):
        """Setup test environment"""
        self.working_memory = WorkingMemory(max_size=100)
    
    def test_working_memory_initialization(self):
        """Test working memory initializes correctly"""
        assert self.working_memory.max_size == 100
        assert len(self.working_memory.cache) == 0
    
    def test_store_and_retrieve_context(self):
        """Test storing and retrieving conversation context"""
        context = ConversationContext(
            session_id="test_session_1",
            user_id="test_user",
            messages=[{"role": "user", "content": "Hello"}],
            metadata={"channel": "test_channel"}
        )
        
        # Store context
        self.working_memory.store_context("test_session_1", context)
        
        # Retrieve context
        retrieved = self.working_memory.get_context("test_session_1")
        assert retrieved is not None
        assert retrieved.session_id == "test_session_1"
        assert retrieved.user_id == "test_user"
        assert len(retrieved.messages) == 1
    
    def test_lru_eviction(self):
        """Test LRU eviction when cache is full"""
        # Create small cache for testing
        small_cache = WorkingMemory(max_size=2)
        
        # Add items to fill cache
        context1 = ConversationContext(session_id="session_1", user_id="user_1", messages=[])
        context2 = ConversationContext(session_id="session_2", user_id="user_2", messages=[])
        context3 = ConversationContext(session_id="session_3", user_id="user_3", messages=[])
        
        small_cache.store_context("session_1", context1)
        small_cache.store_context("session_2", context2)
        
        # This should evict session_1
        small_cache.store_context("session_3", context3)
        
        assert small_cache.get_context("session_1") is None
        assert small_cache.get_context("session_2") is not None
        assert small_cache.get_context("session_3") is not None
    
    def test_update_context(self):
        """Test updating existing context"""
        context = ConversationContext(
            session_id="test_session",
            user_id="test_user",
            messages=[{"role": "user", "content": "Hello"}]
        )
        
        self.working_memory.store_context("test_session", context)
        
        # Update context with new message
        context.messages.append({"role": "assistant", "content": "Hi there!"})
        self.working_memory.store_context("test_session", context)
        
        retrieved = self.working_memory.get_context("test_session")
        assert len(retrieved.messages) == 2


class TestShortTermMemory:
    """Test Short-Term Memory (Redis) functionality"""
    
    def setup_method(self):
        """Setup test environment with mocked Redis"""
        with patch('redis.Redis') as mock_redis:
            mock_redis.return_value = Mock()
            self.short_term_memory = ShortTermMemory(redis_url="redis://localhost:6379")
            self.mock_redis = mock_redis.return_value
    
    @pytest.mark.asyncio
    async def test_store_session_data(self):
        """Test storing session data in Redis"""
        session_data = {
            "user_preferences": {"language": "python", "experience": "senior"},
            "recent_topics": ["fastapi", "memory_optimization"],
            "interaction_count": 5
        }
        
        self.mock_redis.setex.return_value = True
        
        result = await self.short_term_memory.store_session_data(
            "test_session", session_data, ttl=3600
        )
        
        assert result is True
        self.mock_redis.setex.assert_called_once()
    
    @pytest.mark.asyncio
    async def test_retrieve_session_data(self):
        """Test retrieving session data from Redis"""
        expected_data = {
            "user_preferences": {"language": "python"},
            "recent_topics": ["fastapi"]
        }
        
        import json
        self.mock_redis.get.return_value = json.dumps(expected_data)
        
        result = await self.short_term_memory.get_session_data("test_session")
        
        assert result == expected_data
        self.mock_redis.get.assert_called_once_with("session:test_session")
    
    @pytest.mark.asyncio
    async def test_session_data_expiry(self):
        """Test session data expiry handling"""
        self.mock_redis.get.return_value = None
        
        result = await self.short_term_memory.get_session_data("expired_session")
        
        assert result is None


class TestLongTermMemory:
    """Test Long-Term Memory (PostgreSQL) functionality"""
    
    def setup_method(self):
        """Setup test environment with mocked PostgreSQL"""
        with patch('asyncpg.connect') as mock_connect:
            mock_conn = AsyncMock()
            mock_connect.return_value = mock_conn
            self.long_term_memory = LongTermMemory(
                postgres_url="postgresql://localhost:5432/testdb"
            )
            self.mock_conn = mock_conn
    
    @pytest.mark.asyncio
    async def test_store_knowledge(self):
        """Test storing knowledge in PostgreSQL"""
        knowledge_data = {
            "topic": "memory_optimization",
            "content": "Enhanced token allocation improves context retention",
            "tags": ["optimization", "memory", "tokens"],
            "user_id": "test_user"
        }
        
        self.mock_conn.execute.return_value = "INSERT 0 1"
        
        result = await self.long_term_memory.store_knowledge(knowledge_data)
        
        assert result is True
        self.mock_conn.execute.assert_called()
    
    @pytest.mark.asyncio
    async def test_semantic_search(self):
        """Test semantic search in long-term memory"""
        query = "token optimization techniques"
        
        mock_results = [
            {
                "id": 1,
                "content": "Enhanced token allocation provides 3.5x improvement",
                "similarity": 0.85,
                "tags": ["optimization", "tokens"]
            },
            {
                "id": 2, 
                "content": "Memory-aware allocation reaches 80% utilization",
                "similarity": 0.78,
                "tags": ["memory", "allocation"]
            }
        ]
        
        self.mock_conn.fetch.return_value = [
            {
                "content": result["content"],
                "similarity": result["similarity"],
                "tags": result["tags"]
            }
            for result in mock_results
        ]
        
        results = await self.long_term_memory.semantic_search(query, limit=5)
        
        assert len(results) == 2
        assert results[0]["similarity"] > results[1]["similarity"]  # Sorted by relevance
    
    @pytest.mark.asyncio
    async def test_store_user_preferences(self):
        """Test storing user preferences"""
        preferences = {
            "user_id": "test_user",
            "programming_languages": ["python", "javascript"],
            "complexity_preference": "advanced",
            "communication_style": "detailed"
        }
        
        self.mock_conn.execute.return_value = "INSERT 0 1"
        
        result = await self.long_term_memory.store_user_preferences(preferences)
        
        assert result is True


class TestMemoryOrchestrator:
    """Test Memory Orchestrator coordination"""
    
    def setup_method(self):
        """Setup test environment with mocked memory layers"""
        self.mock_working = Mock(spec=WorkingMemory)
        self.mock_short_term = Mock(spec=ShortTermMemory)
        self.mock_long_term = Mock(spec=LongTermMemory)
        
        self.orchestrator = MemoryOrchestrator(
            working_memory=self.mock_working,
            short_term_memory=self.mock_short_term,
            long_term_memory=self.mock_long_term
        )
    
    @pytest.mark.asyncio
    async def test_intelligent_retrieval(self):
        """Test intelligent memory retrieval strategy"""
        session_id = "test_session"
        query = "python memory optimization"
        
        # Mock working memory return
        self.mock_working.get_context.return_value = Mock(
            messages=[{"role": "user", "content": "Tell me about memory optimization"}]
        )
        
        # Mock short-term memory return
        self.mock_short_term.get_session_data.return_value = {
            "recent_topics": ["memory", "optimization"],
            "user_preferences": {"language": "python"}
        }
        
        # Mock long-term memory return
        self.mock_long_term.semantic_search.return_value = [
            {"content": "Memory optimization techniques", "similarity": 0.9}
        ]
        
        result = await self.orchestrator.intelligent_retrieval(session_id, query)
        
        assert "working_memory" in result
        assert "short_term_memory" in result
        assert "long_term_memory" in result
        assert len(result["long_term_memory"]) > 0
    
    @pytest.mark.asyncio
    async def test_memory_consolidation(self):
        """Test memory consolidation from working to short-term"""
        session_id = "test_session"
        
        # Mock working memory context
        context = Mock()
        context.messages = [
            {"role": "user", "content": "How to optimize tokens?"},
            {"role": "assistant", "content": "Use 70-80% allocation..."}
        ]
        context.metadata = {"topics": ["optimization", "tokens"]}
        
        self.mock_working.get_context.return_value = context
        self.mock_short_term.store_session_data.return_value = True
        
        result = await self.orchestrator.consolidate_memory(session_id)
        
        assert result is True
        self.mock_short_term.store_session_data.assert_called()
    
    def test_memory_priority_routing(self):
        """Test memory priority routing logic"""
        # Test recent session (should use working memory)
        priority = self.orchestrator.get_memory_priority("recent_session", age_minutes=5)
        assert priority["primary"] == "working"
        
        # Test older session (should use short-term memory)
        priority = self.orchestrator.get_memory_priority("older_session", age_minutes=30)
        assert priority["primary"] == "short_term"
        
        # Test very old session (should use long-term memory)
        priority = self.orchestrator.get_memory_priority("old_session", age_minutes=1440)  # 24 hours
        assert priority["primary"] == "long_term"


class TestMemoryEnhancedZionAgent:
    """Test Memory-Enhanced Zion Agent integration"""
    
    def setup_method(self):
        """Setup test environment"""
        with patch.multiple(
            'zion.agent.memory_enhanced_zion_agent',
            MemoryOrchestrator=Mock(),
            MemoryEnhancedAgentBuilder=Mock()
        ):
            self.agent = MemoryEnhancedZionAgent(
                enable_memory=True,
                redis_url="redis://localhost:6379",
                postgres_url="postgresql://localhost:5432/testdb"
            )
    
    def test_agent_initialization_with_memory(self):
        """Test agent initializes with memory enabled"""
        assert self.agent.enable_memory is True
        assert self.agent.memory_builder is not None
        assert self.agent.memory_orchestrator is not None
    
    def test_agent_initialization_without_memory(self):
        """Test agent initializes with memory disabled"""
        with patch.multiple(
            'zion.agent.memory_enhanced_zion_agent',
            MemoryOrchestrator=Mock(),
            MemoryEnhancedAgentBuilder=Mock()
        ):
            agent = MemoryEnhancedZionAgent(enable_memory=False)
            assert agent.enable_memory is False
    
    @pytest.mark.asyncio
    async def test_memory_enhanced_processing(self):
        """Test memory-enhanced message processing"""
        # Mock memory orchestrator
        self.agent.memory_orchestrator.intelligent_retrieval = AsyncMock(
            return_value={
                "working_memory": {"recent_context": "optimization discussion"},
                "short_term_memory": {"user_preferences": {"language": "python"}},
                "long_term_memory": [{"content": "Memory optimization guide", "similarity": 0.9}]
            }
        )
        
        # Test message with memory context
        message = "How can I optimize memory usage?"
        session_id = "test_session"
        
        # This would normally call the parent class method with enhanced context
        # For testing, we just verify the memory retrieval is called
        await self.agent.memory_orchestrator.intelligent_retrieval(session_id, message)
        
        self.agent.memory_orchestrator.intelligent_retrieval.assert_called_once_with(
            session_id, message
        )


class TestMemoryIntegration:
    """Integration tests for the complete memory system"""
    
    @pytest.mark.asyncio
    async def test_end_to_end_memory_flow(self):
        """Test complete memory flow from storage to retrieval"""
        # This would test the complete flow in a real environment
        # For now, we test the component interactions
        
        with patch('redis.Redis'), patch('asyncpg.connect'):
            # Create memory components
            working = WorkingMemory(max_size=100)
            short_term = ShortTermMemory("redis://localhost:6379")
            long_term = LongTermMemory("postgresql://localhost:5432/testdb")
            orchestrator = MemoryOrchestrator(working, short_term, long_term)
            
            # Test data flow
            session_id = "integration_test"
            
            # 1. Store in working memory
            context = ConversationContext(
                session_id=session_id,
                user_id="test_user",
                messages=[{"role": "user", "content": "Test message"}]
            )
            working.store_context(session_id, context)
            
            # 2. Verify storage
            retrieved = working.get_context(session_id)
            assert retrieved is not None
            assert retrieved.session_id == session_id
    
    def test_memory_performance_metrics(self):
        """Test memory system performance characteristics"""
        working = WorkingMemory(max_size=1000)
        
        # Test performance with many contexts
        import time
        start_time = time.time()
        
        for i in range(100):
            context = ConversationContext(
                session_id=f"session_{i}",
                user_id=f"user_{i}",
                messages=[{"role": "user", "content": f"Message {i}"}]
            )
            working.store_context(f"session_{i}", context)
        
        storage_time = time.time() - start_time
        
        # Retrieval performance
        start_time = time.time()
        for i in range(100):
            working.get_context(f"session_{i}")
        
        retrieval_time = time.time() - start_time
        
        # Performance assertions (adjust based on requirements)
        assert storage_time < 1.0  # Should store 100 contexts in < 1 second
        assert retrieval_time < 0.1  # Should retrieve 100 contexts in < 0.1 second


if __name__ == "__main__":
    pytest.main([__file__, "-v"])