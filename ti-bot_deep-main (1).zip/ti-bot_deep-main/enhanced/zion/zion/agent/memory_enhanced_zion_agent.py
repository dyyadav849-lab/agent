"""
Memory-Enhanced Zion Agent
=========================

Enhanced version of ZionAgent with integrated 3-layer memory system
for improved contextual understanding and personalized interactions.
"""

import asyncio
import logging
from typing import Dict, List, Optional, Any, AsyncGenerator
from datetime import datetime

from langchain_core.messages import HumanMessage, AIMessage
from langchain_core.tools import BaseTool

from .zion_agent import ZionAgent
from .memory_enhanced_agent_builder import MemoryEnhancedAgentBuilder
from ..memory.memory_orchestrator import MemoryOrchestrator
from ..memory.working_memory import ConversationContext

logger = logging.getLogger(__name__)


class MemoryEnhancedZionAgent(ZionAgent):
    """ZionAgent with integrated memory capabilities"""
    
    # Pydantic field declarations
    enable_memory: bool = True
    redis_url: Optional[str] = None
    postgres_url: Optional[str] = None
    memory_builder: Optional[Any] = None
    memory_orchestrator: Optional[Any] = None
    
    def __init__(
        self,
        *args,
        redis_url: Optional[str] = None,
        postgres_url: Optional[str] = None,
        enable_memory: bool = True,
        **kwargs
    ):
        """
        Initialize memory-enhanced Zion agent
        
        Args:
            *args: Arguments for base ZionAgent
            redis_url: Redis connection for short-term memory
            postgres_url: PostgreSQL connection for long-term memory  
            enable_memory: Whether to enable memory features
            **kwargs: Additional arguments for base ZionAgent
        """
        super().__init__(*args, **kwargs)
        
        self.enable_memory = enable_memory
        self.memory_builder = None
        self.memory_orchestrator = None
        
        if enable_memory:
            try:
                self.memory_builder = MemoryEnhancedAgentBuilder(
                    redis_url=redis_url,
                    postgres_url=postgres_url
                )
                self.memory_orchestrator = self.memory_builder.memory_orchestrator
                logger.info("Memory-enhanced ZionAgent initialized successfully")
            except Exception as e:
                logger.warning(f"Failed to initialize memory system: {e}. Falling back to standard mode.")
                self.enable_memory = False
    
    async def ainvoke_with_memory(
        self,
        user_input: str,
        user_id: str,
        session_id: str,
        tools: Optional[List[BaseTool]] = None,
        **kwargs
    ) -> Dict[str, Any]:
        """
        Invoke agent with memory enhancement
        
        Args:
            user_input: User's input message
            user_id: User identifier
            session_id: Session identifier
            tools: Optional tools override
            **kwargs: Additional arguments
            
        Returns:
            Enhanced response with memory context
        """
        if not self.enable_memory or not self.memory_orchestrator:
            # Fallback to standard processing
            return await self.ainvoke(user_input, **kwargs)
        
        try:
            start_time = datetime.now()
            
            # Create conversation context
            conversation_context = ConversationContext(
                conversation_id=f"{user_id}:{session_id}",
                user_id=user_id,
                session_id=session_id,
                current_topic=self._extract_topic(user_input),
                context_summary="",
                last_interaction=start_time,
                metadata={"input_length": len(user_input)}
            )
            
            # Store user interaction in memory
            await self.memory_orchestrator.store_interaction(
                user_id=user_id,
                session_id=session_id,
                user_message=user_input,
                context=conversation_context
            )
            
            # Get memory context for enhanced processing
            memory_context = await self.memory_orchestrator.get_memory_context(
                user_id=user_id,
                session_id=session_id,
                query=user_input
            )
            
            # Enhance input with memory context
            enhanced_input = self._enhance_input_with_memory(user_input, memory_context)
            
            # Process with enhanced context
            response = await self.ainvoke(enhanced_input, **kwargs)
            
            # Store AI response in memory
            if isinstance(response, dict) and "output" in response:
                await self.memory_builder.store_ai_response(
                    user_id=user_id,
                    session_id=session_id,
                    ai_response=response["output"],
                    conversation_context=conversation_context
                )
            
            # Add memory metadata to response
            response["memory_metadata"] = {
                "memory_context_used": len(memory_context) > 0,
                "processing_time": (datetime.now() - start_time).total_seconds(),
                "memory_layers_accessed": ["working", "short_term", "long_term"]
            }
            
            return response
            
        except Exception as e:
            logger.error(f"Error in memory-enhanced processing: {e}")
            # Fallback to standard processing
            return await self.ainvoke(user_input, **kwargs)
    
    async def astream_with_memory(
        self,
        user_input: str,
        user_id: str,
        session_id: str,
        **kwargs
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Stream response with memory enhancement
        
        Args:
            user_input: User's input message
            user_id: User identifier
            session_id: Session identifier
            **kwargs: Additional arguments
            
        Yields:
            Enhanced streaming response chunks
        """
        if not self.enable_memory or not self.memory_orchestrator:
            # Fallback to standard streaming
            async for chunk in self.astream(user_input, **kwargs):
                yield chunk
            return
        
        try:
            # Store user interaction
            conversation_context = ConversationContext(
                conversation_id=f"{user_id}:{session_id}",
                user_id=user_id,
                session_id=session_id,
                current_topic=self._extract_topic(user_input),
                context_summary="",
                last_interaction=datetime.now(),
                metadata={"streaming": True}
            )
            
            await self.memory_orchestrator.store_interaction(
                user_id=user_id,
                session_id=session_id,
                user_message=user_input,
                context=conversation_context
            )
            
            # Get memory context
            memory_context = await self.memory_orchestrator.get_memory_context(
                user_id=user_id,
                session_id=session_id,
                query=user_input
            )
            
            # Enhance input with memory
            enhanced_input = self._enhance_input_with_memory(user_input, memory_context)
            
            # Stream with enhanced context
            full_response = ""
            async for chunk in self.astream(enhanced_input, **kwargs):
                if isinstance(chunk, dict) and "output" in chunk:
                    full_response += chunk["output"]
                yield chunk
            
            # Store complete AI response
            if full_response:
                await self.memory_builder.store_ai_response(
                    user_id=user_id,
                    session_id=session_id,
                    ai_response=full_response,
                    conversation_context=conversation_context
                )
                
        except Exception as e:
            logger.error(f"Error in memory-enhanced streaming: {e}")
            # Fallback to standard streaming
            async for chunk in self.astream(user_input, **kwargs):
                yield chunk
    
    def _extract_topic(self, user_input: str) -> str:
        """Extract main topic from user input"""
        # Simple topic extraction - could be enhanced with NLP
        words = user_input.lower().split()
        
        # Look for key topic indicators
        topic_keywords = ["about", "regarding", "help", "how", "what", "when", "where", "why"]
        
        for i, word in enumerate(words):
            if word in topic_keywords and i + 1 < len(words):
                return " ".join(words[i+1:i+3])  # Next 2 words as topic
        
        # Fallback: first few meaningful words
        meaningful_words = [w for w in words[:5] if len(w) > 3]
        return " ".join(meaningful_words[:2]) if meaningful_words else "general"
    
    def _enhance_input_with_memory(self, user_input: str, memory_context: str) -> str:
        """Enhance user input with memory context"""
        if not memory_context.strip():
            return user_input
        
        enhanced_input = f"""
Based on previous conversations and context:
{memory_context}

Current user input: {user_input}

Please respond considering the historical context and any relevant patterns or preferences."""
        
        return enhanced_input
    
    def get_memory_insights(self, user_id: str, session_id: str) -> Dict[str, Any]:
        """Get memory system insights for debugging/monitoring"""
        if not self.enable_memory or not self.memory_orchestrator:
            return {"status": "memory_disabled"}
        
        try:
            return {
                "memory_enabled": True,
                "user_id": user_id,
                "session_id": session_id,
                "memory_stats": self.memory_builder.get_memory_stats(user_id, session_id),
                "last_access": datetime.now().isoformat()
            }
        except Exception as e:
            logger.error(f"Error getting memory insights: {e}")
            return {"status": "error", "error": str(e)}
    
    async def clear_user_memory(self, user_id: str, session_id: Optional[str] = None) -> bool:
        """Clear memory for specific user/session"""
        if not self.enable_memory or not self.memory_orchestrator:
            return False
        
        try:
            # Clear working memory
            if session_id:
                key = f"{user_id}:{session_id}"
                self.memory_orchestrator.working_memory.memory.pop(key, None)
            else:
                # Clear all sessions for user
                keys_to_remove = [k for k in self.memory_orchestrator.working_memory.memory.keys() 
                                if k.startswith(f"{user_id}:")]
                for key in keys_to_remove:
                    self.memory_orchestrator.working_memory.memory.pop(key, None)
            
            logger.info(f"Cleared memory for user {user_id}, session {session_id}")
            return True
            
        except Exception as e:
            logger.error(f"Error clearing memory: {e}")
            return False


def create_memory_enhanced_zion_agent(
    redis_url: Optional[str] = None,
    postgres_url: Optional[str] = None,
    enable_memory: bool = True,
    **kwargs
) -> MemoryEnhancedZionAgent:
    """
    Factory function to create memory-enhanced Zion agent
    
    Args:
        redis_url: Redis connection for short-term memory
        postgres_url: PostgreSQL connection for long-term memory
        enable_memory: Whether to enable memory features
        **kwargs: Additional arguments for ZionAgent
        
    Returns:
        Memory-enhanced Zion agent instance
    """
    return MemoryEnhancedZionAgent(
        redis_url=redis_url,
        postgres_url=postgres_url,
        enable_memory=enable_memory,
        **kwargs
    )
