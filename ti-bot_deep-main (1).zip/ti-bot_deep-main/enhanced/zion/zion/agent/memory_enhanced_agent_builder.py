"""
Memory-Enhanced Agent Builder
============================

Extended agent builder that integrates the 3-layer memory system
for enhanced conversational context and learning capabilities.
"""

import logging
from typing import Optional, List, Dict, Any
from langchain.agents import AgentExecutor
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.tools import BaseTool
from langchain_core.chat_history import BaseChatMessageHistory
from langchain_core.runnables.history import RunnableWithMessageHistory
from langchain_core.runnables import RunnableLambda
from langchain_core.messages import BaseMessage

from .agent_builder import get_agent_executor
from ..memory.memory_orchestrator import MemoryOrchestrator
from ..memory.working_memory import ConversationContext

logger = logging.getLogger(__name__)

MEMORY_KEY = "chat_history"
MEMORY_CONTEXT_KEY = "memory_context"


class MemoryEnhancedAgentBuilder:
    """Builder for memory-enhanced agents with 3-layer memory integration"""
    
    def __init__(self, redis_url: Optional[str] = None, postgres_url: Optional[str] = None):
        """
        Initialize memory-enhanced agent builder
        
        Args:
            redis_url: Redis connection string for short-term memory
            postgres_url: PostgreSQL connection string for long-term memory
        """
        self.memory_orchestrator = MemoryOrchestrator(
            redis_url=redis_url,
            postgres_url=postgres_url
        )
        
    def build_enhanced_agent(
        self,
        tools: List[BaseTool],
        llm: Any,
        user_id: str,
        session_id: str,
        system_prompt: Optional[str] = None,
        **kwargs
    ) -> RunnableWithMessageHistory:
        """
        Build agent with integrated memory system
        
        Args:
            tools: List of tools for the agent
            llm: Language model instance
            user_id: User identifier for memory persistence
            session_id: Session identifier
            system_prompt: Optional system prompt override
            **kwargs: Additional arguments for agent executor
            
        Returns:
            Memory-enhanced agent executor
        """
        try:
            # Create enhanced prompt with memory context
            enhanced_prompt = self._create_memory_enhanced_prompt(system_prompt)
            
            # Get base agent executor
            base_agent = get_agent_executor(
                tools=tools,
                llm=llm,
                prompt=enhanced_prompt,
                **kwargs
            )
            
            # Create memory-enhanced runnable
            memory_enhanced_agent = self._wrap_with_memory(
                base_agent, user_id, session_id
            )
            
            logger.info(f"Created memory-enhanced agent for user {user_id}, session {session_id}")
            return memory_enhanced_agent
            
        except Exception as e:
            logger.error(f"Error building memory-enhanced agent: {e}")
            # Fallback to standard agent
            return get_agent_executor(tools=tools, llm=llm, **kwargs)
    
    def _create_memory_enhanced_prompt(self, system_prompt: Optional[str] = None) -> ChatPromptTemplate:
        """Create prompt template with memory integration"""
        
        base_system = system_prompt or """You are a helpful AI assistant with enhanced memory capabilities.
        
You have access to:
1. Working Memory: Immediate conversation context
2. Short-term Memory: Session and recent interaction patterns  
3. Long-term Memory: User preferences, knowledge, and insights

Use this memory context to provide more personalized and contextually aware responses.
Memory Context: {memory_context}
"""
        
        return ChatPromptTemplate.from_messages([
            ("system", base_system),
            MessagesPlaceholder(variable_name=MEMORY_KEY),
            ("human", "{input}"),
            MessagesPlaceholder(variable_name="agent_scratchpad"),
        ])
    
    def _wrap_with_memory(
        self, 
        agent: AgentExecutor, 
        user_id: str, 
        session_id: str
    ) -> RunnableWithMessageHistory:
        """Wrap agent with memory-enhanced message history"""
        
        def get_session_history(session_id: str) -> BaseChatMessageHistory:
            """Get chat history with memory enhancement"""
            # Create a simple in-memory chat history
            # In production, this could be enhanced with persistent storage
            from langchain_core.chat_history import InMemoryChatMessageHistory
            return InMemoryChatMessageHistory()
        
        # Create memory-enhanced chain
        memory_chain = agent | self._memory_enhancement_chain(user_id, session_id)
        
        return RunnableWithMessageHistory(
            memory_chain,
            get_session_history,
            input_messages_key="input",
            history_messages_key=MEMORY_KEY,
        )
    
    def _memory_enhancement_chain(self, user_id: str, session_id: str):
        """Create chain that enhances input/output with memory"""
        
        async def enhance_with_memory(inputs: Dict[str, Any]) -> Dict[str, Any]:
            """Enhance agent interaction with memory context"""
            try:
                # Get current conversation context
                conversation_context = ConversationContext(
                    conversation_id=f"{user_id}:{session_id}",
                    user_id=user_id,
                    session_id=session_id,
                    current_topic="",  # Will be extracted from input
                    context_summary="",
                    last_interaction=None,
                    metadata={}
                )
                
                # Store interaction in memory
                await self.memory_orchestrator.store_interaction(
                    user_id=user_id,
                    session_id=session_id,
                    user_message=inputs.get("input", ""),
                    context=conversation_context
                )
                
                # Retrieve memory context
                memory_context = await self.memory_orchestrator.get_memory_context(
                    user_id=user_id,
                    session_id=session_id,
                    query=inputs.get("input", "")
                )
                
                # Add memory context to inputs
                inputs[MEMORY_CONTEXT_KEY] = memory_context
                
                return inputs
                
            except Exception as e:
                logger.error(f"Error in memory enhancement: {e}")
                inputs[MEMORY_CONTEXT_KEY] = "Memory system unavailable"
                return inputs
        
        return RunnableLambda(enhance_with_memory)
    
    async def store_ai_response(
        self, 
        user_id: str, 
        session_id: str, 
        ai_response: str,
        conversation_context: Optional[ConversationContext] = None
    ):
        """Store AI response in memory system"""
        try:
            if not conversation_context:
                conversation_context = ConversationContext(
                    conversation_id=f"{user_id}:{session_id}",
                    user_id=user_id,
                    session_id=session_id,
                    current_topic="",
                    context_summary="",
                    last_interaction=None,
                    metadata={}
                )
            
            await self.memory_orchestrator.store_interaction(
                user_id=user_id,
                session_id=session_id,
                ai_message=ai_response,
                context=conversation_context
            )
            
        except Exception as e:
            logger.error(f"Error storing AI response in memory: {e}")
    
    def get_memory_stats(self, user_id: str, session_id: str) -> Dict[str, Any]:
        """Get memory system statistics"""
        try:
            return {
                "working_memory_size": len(self.memory_orchestrator.working_memory.memory),
                "user_id": user_id,
                "session_id": session_id,
                "memory_layers": ["working", "short_term", "long_term"],
                "status": "active"
            }
        except Exception as e:
            logger.error(f"Error getting memory stats: {e}")
            return {"status": "error", "error": str(e)}


def get_memory_enhanced_agent_executor(
    tools: List[BaseTool],
    llm: Any,
    user_id: str,
    session_id: str,
    redis_url: Optional[str] = None,
    postgres_url: Optional[str] = None,
    **kwargs
) -> RunnableWithMessageHistory:
    """
    Convenience function to create memory-enhanced agent
    
    Args:
        tools: List of tools for the agent
        llm: Language model instance  
        user_id: User identifier
        session_id: Session identifier
        redis_url: Redis connection for short-term memory
        postgres_url: PostgreSQL connection for long-term memory
        **kwargs: Additional agent configuration
        
    Returns:
        Memory-enhanced agent executor
    """
    builder = MemoryEnhancedAgentBuilder(
        redis_url=redis_url,
        postgres_url=postgres_url
    )
    
    return builder.build_enhanced_agent(
        tools=tools,
        llm=llm,
        user_id=user_id,
        session_id=session_id,
        **kwargs
    )
