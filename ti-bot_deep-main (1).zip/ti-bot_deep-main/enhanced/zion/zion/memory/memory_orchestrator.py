"""
Memory Orchestrator
==================

Central coordinator for multi-level memory management.
Integrates working memory, short-term memory, and long-term memory
into a unified memory system for enhanced AI interactions.
"""

import json
import asyncio
import time
from typing import Dict, List, Optional, Any, Tuple, Union
from datetime import datetime, timedelta
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, SystemMessage
from dataclasses import dataclass, asdict
import logging

from .working_memory import WorkingMemory, ConversationContext
from .short_term import ShortTermMemory, SessionMemory
from .long_term import LongTermMemory, LongTermMemoryData

logger = logging.getLogger(__name__)


@dataclass
class MemoryInsight:
    """Memory insight extracted from analysis"""
    insight_type: str  # pattern, preference, knowledge, workflow
    content: str
    confidence_score: float
    source_layer: str  # working, short_term, long_term
    metadata: Dict[str, Any]


@dataclass
class ContextualMemory:
    """Unified memory context for AI responses"""
    working_context: ConversationContext
    session_data: Optional[SessionMemory]
    long_term_data: Optional[LongTermMemoryData]
    insights: List[MemoryInsight]
    memory_summary: str
    relevance_score: float


class MemoryOrchestrator:
    """
    Central orchestrator for multi-level memory management.
    Coordinates working memory, short-term memory, and long-term memory.
    """
    
    def __init__(self, 
                 redis_host: str = "localhost",
                 redis_port: int = 6379,
                 redis_db: int = 0,
                 database_url: Optional[str] = None,
                 enable_fallbacks: bool = True,
                 working_memory: Optional[WorkingMemory] = None,
                 short_term_memory: Optional[ShortTermMemory] = None,
                 long_term_memory: Optional[LongTermMemory] = None):
        
        self.enable_fallbacks = enable_fallbacks
        
        # Initialize memory layers
        self.working_memory = working_memory or WorkingMemory()
        
        try:
            self.short_term_memory = short_term_memory or ShortTermMemory(
                redis_host=redis_host,
                redis_port=redis_port,
                redis_db=redis_db
            )
        except Exception as e:
            logger.warning(f"Short-term memory initialization failed: {e}")
            if enable_fallbacks:
                self.short_term_memory = None
            else:
                raise
        
        try:
            self.long_term_memory = long_term_memory or LongTermMemory(
                database_url=database_url,
                fallback_to_sqlite=enable_fallbacks
            )
        except Exception as e:
            logger.warning(f"Long-term memory initialization failed: {e}")
            if enable_fallbacks:
                self.long_term_memory = None
            else:
                raise
        
        logger.info("Memory Orchestrator initialized")
    
    def add_message(self, user_id: str, session_id: str, message: BaseMessage) -> bool:
        """Add message to all appropriate memory layers"""
        success_count = 0
        
        # Add to working memory (always available)
        try:
            self.working_memory.append_message(session_id, message)
            success_count += 1
        except Exception as e:
            logger.error(f"Failed to add message to working memory: {e}")
        
        # Add to short-term memory
        if self.short_term_memory:
            try:
                if self.short_term_memory.append_message(session_id, message):
                    success_count += 1
            except Exception as e:
                logger.error(f"Failed to add message to short-term memory: {e}")
        
        # Add to long-term memory
        if self.long_term_memory:
            try:
                if self.long_term_memory.store_conversation_message(
                    user_id, session_id, message
                ):
                    success_count += 1
            except Exception as e:
                logger.error(f"Failed to add message to long-term memory: {e}")
        
        return success_count > 0
    
    def get_memory_priority(self, session_id: str, age_minutes: int = 0) -> Dict[str, str]:
        """
        Determine memory priority routing based on session age and activity
        
        Args:
            session_id: Session identifier  
            age_minutes: Age of session in minutes
            
        Returns:
            Priority routing info with primary and secondary memory layers
        """
        # Recent sessions (< 30 minutes) use working memory
        if age_minutes < 30:
            return {"primary": "working", "secondary": "short_term"}
        
        # Medium-term sessions (30 minutes to 24 hours) use short-term memory
        if age_minutes < 1440:  # 24 hours
            return {"primary": "short_term", "secondary": "long_term"}
        
        # Older sessions use long-term memory
        return {"primary": "long_term", "secondary": "short_term"}
    
    async def consolidate_memory(self, session_id: str) -> bool:
        """
        Consolidate memory from working to short-term storage
        
        Args:
            session_id: Session identifier
            
        Returns:
            True if consolidation successful, False otherwise
        """
        try:
            # Get context from working memory
            if not self.working_memory:
                return False
                
            context = self.working_memory.get_context(session_id)
            if not context:
                logger.debug(f"No context found in working memory for session {session_id}")
                return False
            
            # Convert context to session data
            session_data = {
                "messages": context.messages if hasattr(context, 'messages') else [],
                "metadata": context.metadata if hasattr(context, 'metadata') else {},
                "consolidated_at": time.time()
            }
            
            # Store in short-term memory if available
            if self.short_term_memory:
                result = await self.short_term_memory.store_session_data(session_id, session_data)
                if result:
                    logger.info(f"Successfully consolidated memory for session {session_id}")
                    return True
                else:
                    logger.error(f"Failed to store consolidated memory for session {session_id}")
                    return False
            else:
                logger.warn("Short-term memory not available for consolidation")
                return False
                
        except Exception as e:
            logger.error(f"Failed to consolidate memory for session {session_id}: {e}")
            return False
    
    def get_contextual_memory(self, user_id: str, session_id: str, 
                            current_query: str = None,
                            include_insights: bool = True) -> ContextualMemory:
        """Get unified contextual memory from all layers"""
        
        # Get working memory context
        working_context = self.working_memory.get_context(session_id)
        
        # Get short-term memory data
        session_data = None
        if self.short_term_memory:
            try:
                session_data = self.short_term_memory.get_session_memory(session_id)
            except Exception as e:
                logger.error(f"Failed to get short-term memory: {e}")
        
        # Get long-term memory data
        long_term_data = None
        if self.long_term_memory:
            try:
                long_term_data = self.long_term_memory.get_comprehensive_memory(
                    user_id, current_query
                )
            except Exception as e:
                logger.error(f"Failed to get long-term memory: {e}")
        
        # Generate insights
        insights = []
        if include_insights:
            insights = self._extract_insights(
                working_context, session_data, long_term_data, current_query
            )
        
        # Generate memory summary
        memory_summary = self._generate_memory_summary(
            working_context, session_data, long_term_data, insights
        )
        
        # Calculate relevance score
        relevance_score = self._calculate_relevance_score(
            working_context, session_data, long_term_data, current_query
        )
        
        return ContextualMemory(
            working_context=working_context,
            session_data=session_data,
            long_term_data=long_term_data,
            insights=insights,
            memory_summary=memory_summary,
            relevance_score=relevance_score
        )
    
    def _extract_insights(self, working_context: ConversationContext,
                         session_data: Optional[SessionMemory],
                         long_term_data: Optional[LongTermMemoryData],
                         current_query: str = None) -> List[MemoryInsight]:
        """Extract actionable insights from memory layers"""
        insights = []
        
        # Working memory insights
        if working_context and working_context.messages:
            # Recent conversation patterns
            recent_messages = working_context.messages[-5:]
            if len(recent_messages) >= 3:
                question_count = sum(1 for msg in recent_messages 
                                   if isinstance(msg, HumanMessage) and '?' in str(msg.content))
                if question_count >= 2:
                    insights.append(MemoryInsight(
                        insight_type="pattern",
                        content="User is asking multiple questions in quick succession",
                        confidence_score=0.8,
                        source_layer="working",
                        metadata={"question_count": question_count, "message_count": len(recent_messages)}
                    ))
            
            # Context complexity analysis
            if working_context.complexity_score > 0.7:
                insights.append(MemoryInsight(
                    insight_type="workflow",
                    content="Current conversation has high complexity, may need detailed responses",
                    confidence_score=working_context.complexity_score,
                    source_layer="working",
                    metadata={"complexity_score": working_context.complexity_score}
                ))
        
        # Session memory insights
        if session_data:
            # Session duration patterns
            if session_data.metadata.get("duration_minutes", 0) > 30:
                insights.append(MemoryInsight(
                    insight_type="pattern",
                    content="Extended session duration indicates deep engagement",
                    confidence_score=0.7,
                    source_layer="short_term",
                    metadata={"duration": session_data.metadata.get("duration_minutes")}
                ))
            
            # Topic consistency
            if session_data.metadata.get("topic_consistency", 0) > 0.8:
                insights.append(MemoryInsight(
                    insight_type="preference",
                    content="User maintains consistent topic focus in this session",
                    confidence_score=session_data.metadata.get("topic_consistency", 0),
                    source_layer="short_term",
                    metadata={"consistency": session_data.metadata.get("topic_consistency")}
                ))
        
        # Long-term memory insights
        if long_term_data:
            # Domain expertise
            if long_term_data.domain_expertise:
                for domain in long_term_data.domain_expertise[:3]:  # Top 3 domains
                    insights.append(MemoryInsight(
                        insight_type="knowledge",
                        content=f"User has expertise in {domain}",
                        confidence_score=0.9,
                        source_layer="long_term",
                        metadata={"domain": domain}
                    ))
            
            # Interaction style preferences
            style = long_term_data.interaction_preferences.get("style", "balanced")
            if style != "balanced":
                insights.append(MemoryInsight(
                    insight_type="preference",
                    content=f"User prefers {style} communication style",
                    confidence_score=0.8,
                    source_layer="long_term",
                    metadata={"style": style}
                ))
            
            # Relevant knowledge
            for knowledge in long_term_data.relevant_knowledge[:2]:  # Top 2 most relevant
                if knowledge.get("confidence_score", 0) > 0.7:
                    insights.append(MemoryInsight(
                        insight_type="knowledge",
                        content=f"Relevant past knowledge: {knowledge.get('content', '')[:100]}...",
                        confidence_score=knowledge.get("confidence_score", 0),
                        source_layer="long_term",
                        metadata={"knowledge_type": knowledge.get("knowledge_type")}
                    ))
        
        return insights
    
    def _generate_memory_summary(self, working_context: ConversationContext,
                               session_data: Optional[SessionMemory],
                               long_term_data: Optional[LongTermMemoryData],
                               insights: List[MemoryInsight]) -> str:
        """Generate concise memory summary for context"""
        summary_parts = []
        
        # Working memory summary
        if working_context and working_context.messages:
            msg_count = len(working_context.messages)
            summary_parts.append(f"Current conversation: {msg_count} messages")
            
            if working_context.complexity_score > 0.6:
                summary_parts.append("(complex discussion)")
        
        # Session summary
        if session_data:
            duration = session_data.metadata.get("duration_minutes", 0)
            if duration > 0:
                summary_parts.append(f"Session: {duration} minutes")
        
        # User profile summary
        if long_term_data:
            if long_term_data.domain_expertise:
                domains = ", ".join(long_term_data.domain_expertise[:2])
                summary_parts.append(f"Expertise: {domains}")
            
            style = long_term_data.interaction_preferences.get("style", "balanced")
            if style != "balanced":
                summary_parts.append(f"Style: {style}")
        
        # Key insights
        high_confidence_insights = [i for i in insights if i.confidence_score > 0.8]
        if high_confidence_insights:
            insight_types = set(i.insight_type for i in high_confidence_insights)
            summary_parts.append(f"Key insights: {', '.join(insight_types)}")
        
        return " | ".join(summary_parts) if summary_parts else "No memory context available"
    
    def _calculate_relevance_score(self, working_context: ConversationContext,
                                 session_data: Optional[SessionMemory],
                                 long_term_data: Optional[LongTermMemoryData],
                                 current_query: str = None) -> float:
        """Calculate overall relevance score of memory context"""
        scores = []
        
        # Working memory relevance
        if working_context and working_context.messages:
            # More recent messages = higher relevance
            base_score = min(1.0, len(working_context.messages) / 10)
            complexity_bonus = working_context.complexity_score * 0.3
            scores.append(base_score + complexity_bonus)
        
        # Session memory relevance
        if session_data:
            # Longer sessions with topic consistency = higher relevance
            duration_score = min(1.0, session_data.metadata.get("duration_minutes", 0) / 60)
            consistency_score = session_data.metadata.get("topic_consistency", 0.5)
            scores.append((duration_score + consistency_score) / 2)
        
        # Long-term memory relevance
        if long_term_data:
            relevance_factors = []
            
            # Domain expertise relevance
            if long_term_data.domain_expertise:
                relevance_factors.append(0.8)  # High relevance if expertise available
            
            # Recent conversation history
            if long_term_data.conversation_history:
                history_recency = min(1.0, len(long_term_data.conversation_history) / 20)
                relevance_factors.append(history_recency)
            
            # Relevant knowledge
            if long_term_data.relevant_knowledge:
                avg_confidence = sum(k.get("confidence_score", 0) 
                                   for k in long_term_data.relevant_knowledge) / len(long_term_data.relevant_knowledge)
                relevance_factors.append(avg_confidence)
            
            if relevance_factors:
                scores.append(sum(relevance_factors) / len(relevance_factors))
        
        return sum(scores) / len(scores) if scores else 0.0
    
    def store_insight(self, user_id: str, session_id: str, insight: MemoryInsight) -> bool:
        """Store insight in appropriate memory layer"""
        if insight.source_layer == "long_term" and self.long_term_memory:
            try:
                return self.long_term_memory.store_knowledge(
                    user_id=user_id,
                    knowledge_type=insight.insight_type,
                    topic="memory_insight",
                    content=insight.content,
                    source_session=session_id,
                    confidence_score=insight.confidence_score
                )
            except Exception as e:
                logger.error(f"Failed to store insight in long-term memory: {e}")
        
        return False
    
    def learn_user_pattern(self, user_id: str, pattern_type: str, 
                          pattern_data: Dict[str, Any]) -> bool:
        """Learn and store user pattern"""
        if self.long_term_memory:
            try:
                topic = pattern_data.get("topic", "general")
                return self.long_term_memory.store_user_pattern(
                    user_id=user_id,
                    topic=topic,
                    pattern_type=pattern_type,
                    pattern_data=pattern_data
                )
            except Exception as e:
                logger.error(f"Failed to store user pattern: {e}")
        
        return False
    
    def cleanup_session(self, session_id: str) -> bool:
        """Clean up session from short-term memory"""
        if self.short_term_memory:
            try:
                return self.short_term_memory.clear_session(session_id)
            except Exception as e:
                logger.error(f"Failed to cleanup session: {e}")
        
        return False
    
    def get_memory_health(self) -> Dict[str, Any]:
        """Get health status of all memory layers"""
        health = {
            "timestamp": datetime.utcnow().isoformat(),
            "overall_status": "healthy",
            "layers": {}
        }
        
        # Working memory health
        try:
            working_stats = self.working_memory.get_memory_stats()
            health["layers"]["working"] = {
                "status": "healthy",
                "stats": working_stats
            }
        except Exception as e:
            health["layers"]["working"] = {
                "status": "error",
                "error": str(e)
            }
            health["overall_status"] = "degraded"
        
        # Short-term memory health
        if self.short_term_memory:
            try:
                short_term_stats = self.short_term_memory.get_memory_stats()
                health["layers"]["short_term"] = {
                    "status": "healthy",
                    "stats": short_term_stats
                }
            except Exception as e:
                health["layers"]["short_term"] = {
                    "status": "error",
                    "error": str(e)
                }
                health["overall_status"] = "degraded"
        else:
            health["layers"]["short_term"] = {
                "status": "disabled",
                "reason": "Redis not available"
            }
        
        # Long-term memory health
        if self.long_term_memory:
            try:
                long_term_stats = self.long_term_memory.get_memory_stats()
                health["layers"]["long_term"] = {
                    "status": "healthy",
                    "stats": long_term_stats
                }
            except Exception as e:
                health["layers"]["long_term"] = {
                    "status": "error",
                    "error": str(e)
                }
                health["overall_status"] = "degraded"
        else:
            health["layers"]["long_term"] = {
                "status": "disabled",
                "reason": "Database not available"
            }
        
        return health
    
    def optimize_memory(self) -> Dict[str, Any]:
        """Perform memory optimization across all layers"""
        results = {
            "timestamp": datetime.utcnow().isoformat(),
            "operations": {}
        }
        
        # Optimize working memory
        try:
            self.working_memory._cleanup_expired_sessions()
            active_sessions = len(self.working_memory.get_active_sessions())
            results["operations"]["working_memory"] = {
                "status": "success",
                "active_sessions_after_cleanup": active_sessions
            }
        except Exception as e:
            results["operations"]["working_memory"] = {
                "status": "error",
                "error": str(e)
            }
        
        # Optimize short-term memory
        if self.short_term_memory:
            try:
                # Redis cleanup happens automatically via TTL
                results["operations"]["short_term_memory"] = {
                    "status": "success",
                    "note": "Redis TTL handles automatic cleanup"
                }
            except Exception as e:
                results["operations"]["short_term_memory"] = {
                    "status": "error",
                    "error": str(e)
                }
        
        # Optimize long-term memory
        if self.long_term_memory:
            try:
                cleanup_results = self.long_term_memory.cleanup_old_data(days_to_keep=90)
                results["operations"]["long_term_memory"] = {
                    "status": "success",
                    "cleanup_results": cleanup_results
                }
            except Exception as e:
                results["operations"]["long_term_memory"] = {
                    "status": "error",
                    "error": str(e)
                }
        
        return results
    
    def export_user_memory(self, user_id: str, session_id: str = None) -> Dict[str, Any]:
        """Export all memory data for a user"""
        export_data = {
            "user_id": user_id,
            "export_timestamp": datetime.utcnow().isoformat(),
            "working_memory": None,
            "long_term_memory": None
        }
        
        # Export working memory (if session_id provided)
        if session_id:
            try:
                working_context = self.working_memory.get_context(session_id)
                if working_context:
                    export_data["working_memory"] = {
                        "session_id": session_id,
                        "message_count": len(working_context.messages),
                        "complexity_score": working_context.complexity_score,
                        "created_at": working_context.created_at.isoformat(),
                        "last_updated": working_context.last_updated.isoformat()
                    }
            except Exception as e:
                export_data["working_memory"] = {"error": str(e)}
        else:
            export_data["working_memory"] = {"note": "No session_id provided for working memory export"}
        
        # Export long-term memory
        if self.long_term_memory:
            try:
                long_term_data = self.long_term_memory.get_comprehensive_memory(user_id)
                export_data["long_term_memory"] = {
                    "user_patterns": long_term_data.user_patterns,
                    "conversation_history_count": len(long_term_data.conversation_history),
                    "domain_expertise": long_term_data.domain_expertise,
                    "interaction_preferences": long_term_data.interaction_preferences,
                    "knowledge_items_count": len(long_term_data.relevant_knowledge)
                }
            except Exception as e:
                export_data["long_term_memory"] = {"error": str(e)}
        
        return export_data
