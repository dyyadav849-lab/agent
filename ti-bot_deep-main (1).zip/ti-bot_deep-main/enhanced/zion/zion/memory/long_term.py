"""
Long-Term Memory Implementation
PostgreSQL-based persistent memory with vector storage for semantic search
"""

import json
import time
import psycopg2
import numpy as np
from typing import Dict, Any, Optional, List, Tuple
from dataclasses import dataclass, asdict
import logging
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

@dataclass
class LongTermMemoryData:
    """Data structure for long-term memory entries"""
    memory_id: str
    user_id: str
    session_id: str
    content: str
    content_type: str  # 'conversation', 'insight', 'preference', 'context'
    metadata: Dict[str, Any]
    embedding: Optional[List[float]]
    created_at: float
    accessed_at: float
    access_count: int = 0
    importance_score: float = 0.0

class LongTermMemory:
    """
    PostgreSQL-based long-term memory with semantic search capabilities
    Stores important conversation patterns, user preferences, and insights
    """
    
    def __init__(self, connection_string: str = None, postgres_url: str = None, embedding_dim: int = 384):
        """
        Initialize long-term memory
        
        Args:
            connection_string: PostgreSQL connection string
            postgres_url: Alternative parameter name for PostgreSQL URL (same as connection_string)
            embedding_dim: Dimension of embedding vectors
        """
        # Accept either parameter name for compatibility
        self.connection_string = connection_string or postgres_url or "postgresql://user:password@localhost:5432/tibot_memory"
        self.embedding_dim = embedding_dim
        self.created_at = time.time()
        
        try:
            self.connection = psycopg2.connect(self.connection_string)
            self.connection.autocommit = True
            self._init_database()
            logger.info("Long-term memory connected to PostgreSQL")
            
        except psycopg2.Error as e:
            logger.warning(f"PostgreSQL not available: {e}, using fallback storage")
            self.connection = None
            self.fallback_storage: Dict[str, LongTermMemoryData] = {}
    
    def _init_database(self):
        """Initialize database tables if they don't exist"""
        if not self.connection:
            return
            
        try:
            cursor = self.connection.cursor()
            
            # Create long-term memory table
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS long_term_memory (
                    memory_id VARCHAR(255) PRIMARY KEY,
                    user_id VARCHAR(255) NOT NULL,
                    session_id VARCHAR(255) NOT NULL,
                    content TEXT NOT NULL,
                    content_type VARCHAR(50) NOT NULL,
                    metadata JSONB DEFAULT '{}',
                    embedding FLOAT[] DEFAULT NULL,
                    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    accessed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    access_count INTEGER DEFAULT 0,
                    importance_score FLOAT DEFAULT 0.0
                );
            """)
            
            # Create indices for performance
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ltm_user_id ON long_term_memory(user_id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ltm_session_id ON long_term_memory(session_id);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ltm_content_type ON long_term_memory(content_type);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ltm_importance ON long_term_memory(importance_score DESC);")
            cursor.execute("CREATE INDEX IF NOT EXISTS idx_ltm_accessed ON long_term_memory(accessed_at DESC);")
            
            cursor.close()
            logger.info("Long-term memory database initialized")
            
        except psycopg2.Error as e:
            logger.error(f"Failed to initialize database: {e}")
    
    def store_memory(self, memory_data: LongTermMemoryData) -> bool:
        """
        Store memory in long-term storage
        
        Args:
            memory_data: LongTermMemoryData object to store
            
        Returns:
            True if stored successfully
        """
        try:
            if self.connection:
                cursor = self.connection.cursor()
                
                cursor.execute("""
                    INSERT INTO long_term_memory 
                    (memory_id, user_id, session_id, content, content_type, metadata, 
                     embedding, created_at, accessed_at, access_count, importance_score)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s)
                    ON CONFLICT (memory_id) DO UPDATE SET
                        content = EXCLUDED.content,
                        metadata = EXCLUDED.metadata,
                        embedding = EXCLUDED.embedding,
                        accessed_at = EXCLUDED.accessed_at,
                        access_count = EXCLUDED.access_count,
                        importance_score = EXCLUDED.importance_score
                """, (
                    memory_data.memory_id,
                    memory_data.user_id,
                    memory_data.session_id,
                    memory_data.content,
                    memory_data.content_type,
                    json.dumps(memory_data.metadata),
                    memory_data.embedding,
                    datetime.fromtimestamp(memory_data.created_at),
                    datetime.fromtimestamp(memory_data.accessed_at),
                    memory_data.access_count,
                    memory_data.importance_score
                ))
                
                cursor.close()
                logger.debug(f"Stored long-term memory {memory_data.memory_id}")
            else:
                # Fallback storage
                self.fallback_storage[memory_data.memory_id] = memory_data
                logger.debug(f"Stored long-term memory {memory_data.memory_id} in fallback storage")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to store long-term memory {memory_data.memory_id}: {e}")
            return False
    
    def retrieve_memory(self, memory_id: str) -> Optional[LongTermMemoryData]:
        """
        Retrieve specific memory by ID
        
        Args:
            memory_id: Memory identifier
            
        Returns:
            LongTermMemoryData if found, None otherwise
        """
        try:
            if self.connection:
                cursor = self.connection.cursor()
                
                cursor.execute("""
                    SELECT memory_id, user_id, session_id, content, content_type, metadata,
                           embedding, EXTRACT(EPOCH FROM created_at), EXTRACT(EPOCH FROM accessed_at),
                           access_count, importance_score
                    FROM long_term_memory 
                    WHERE memory_id = %s
                """, (memory_id,))
                
                row = cursor.fetchone()
                cursor.close()
                
                if row:
                    # Update access info
                    self._update_access_info(memory_id)
                    
                    return LongTermMemoryData(
                        memory_id=row[0],
                        user_id=row[1],
                        session_id=row[2],
                        content=row[3],
                        content_type=row[4],
                        metadata=json.loads(row[5]) if row[5] else {},
                        embedding=row[6],
                        created_at=row[7],
                        accessed_at=row[8],
                        access_count=row[9] + 1,
                        importance_score=row[10]
                    )
            else:
                # Fallback storage
                if memory_id in self.fallback_storage:
                    memory = self.fallback_storage[memory_id]
                    memory.access_count += 1
                    memory.accessed_at = time.time()
                    return memory
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to retrieve memory {memory_id}: {e}")
            return None
    
    def search_memories(self, user_id: str, query_embedding: Optional[List[float]] = None, 
                       content_type: Optional[str] = None, limit: int = 10) -> List[LongTermMemoryData]:
        """
        Search memories for a user with optional semantic search
        
        Args:
            user_id: User identifier
            query_embedding: Optional embedding for semantic search
            content_type: Optional filter by content type
            limit: Maximum number of results
            
        Returns:
            List of LongTermMemoryData objects
        """
        memories = []
        try:
            if self.connection:
                cursor = self.connection.cursor()
                
                # Build query based on parameters
                base_query = """
                    SELECT memory_id, user_id, session_id, content, content_type, metadata,
                           embedding, EXTRACT(EPOCH FROM created_at), EXTRACT(EPOCH FROM accessed_at),
                           access_count, importance_score
                    FROM long_term_memory 
                    WHERE user_id = %s
                """
                params = [user_id]
                
                if content_type:
                    base_query += " AND content_type = %s"
                    params.append(content_type)
                
                # For now, order by importance and access time (semantic search would require pgvector)
                base_query += " ORDER BY importance_score DESC, accessed_at DESC LIMIT %s"
                params.append(limit)
                
                cursor.execute(base_query, params)
                rows = cursor.fetchall()
                cursor.close()
                
                for row in rows:
                    memories.append(LongTermMemoryData(
                        memory_id=row[0],
                        user_id=row[1],
                        session_id=row[2],
                        content=row[3],
                        content_type=row[4],
                        metadata=json.loads(row[5]) if row[5] else {},
                        embedding=row[6],
                        created_at=row[7],
                        accessed_at=row[8],
                        access_count=row[9],
                        importance_score=row[10]
                    ))
            else:
                # Fallback storage search
                for memory in self.fallback_storage.values():
                    if memory.user_id == user_id:
                        if not content_type or memory.content_type == content_type:
                            memories.append(memory)
                
                # Sort by importance and access time
                memories.sort(key=lambda m: (m.importance_score, m.accessed_at), reverse=True)
                memories = memories[:limit]
            
            logger.debug(f"Found {len(memories)} memories for user {user_id}")
            return memories
            
        except Exception as e:
            logger.error(f"Failed to search memories for user {user_id}: {e}")
            return []
    
    def get_user_memories(self, user_id: str, limit: int = 50) -> List[LongTermMemoryData]:
        """
        Get all memories for a user
        
        Args:
            user_id: User identifier
            limit: Maximum number of memories to return
            
        Returns:
            List of LongTermMemoryData objects
        """
        return self.search_memories(user_id, limit=limit)
    
    def _update_access_info(self, memory_id: str):
        """Update access time and count for a memory"""
        if not self.connection:
            return
            
        try:
            cursor = self.connection.cursor()
            cursor.execute("""
                UPDATE long_term_memory 
                SET accessed_at = CURRENT_TIMESTAMP, access_count = access_count + 1
                WHERE memory_id = %s
            """, (memory_id,))
            cursor.close()
            
        except Exception as e:
            logger.error(f"Failed to update access info for {memory_id}: {e}")
    
    def delete_memory(self, memory_id: str) -> bool:
        """
        Delete a memory from long-term storage
        
        Args:
            memory_id: Memory identifier
            
        Returns:
            True if deleted successfully
        """
        try:
            if self.connection:
                cursor = self.connection.cursor()
                cursor.execute("DELETE FROM long_term_memory WHERE memory_id = %s", (memory_id,))
                affected_rows = cursor.rowcount
                cursor.close()
                
                logger.debug(f"Deleted memory {memory_id} from PostgreSQL")
                return affected_rows > 0
            else:
                if memory_id in self.fallback_storage:
                    del self.fallback_storage[memory_id]
                    logger.debug(f"Deleted memory {memory_id} from fallback storage")
                    return True
                return False
                
        except Exception as e:
            logger.error(f"Failed to delete memory {memory_id}: {e}")
            return False
    
    def cleanup_old_memories(self, user_id: str, days_old: int = 90) -> int:
        """
        Clean up old memories for a user
        
        Args:
            user_id: User identifier
            days_old: Delete memories older than this many days
            
        Returns:
            Number of memories deleted
        """
        try:
            cutoff_time = datetime.now() - timedelta(days=days_old)
            
            if self.connection:
                cursor = self.connection.cursor()
                cursor.execute("""
                    DELETE FROM long_term_memory 
                    WHERE user_id = %s AND created_at < %s AND importance_score < 0.5
                """, (user_id, cutoff_time))
                
                deleted_count = cursor.rowcount
                cursor.close()
                
                logger.info(f"Cleaned up {deleted_count} old memories for user {user_id}")
                return deleted_count
            else:
                # Fallback cleanup
                cutoff_timestamp = cutoff_time.timestamp()
                to_delete = []
                
                for memory_id, memory in self.fallback_storage.items():
                    if (memory.user_id == user_id and 
                        memory.created_at < cutoff_timestamp and 
                        memory.importance_score < 0.5):
                        to_delete.append(memory_id)
                
                for memory_id in to_delete:
                    del self.fallback_storage[memory_id]
                
                logger.info(f"Cleaned up {len(to_delete)} old memories for user {user_id} from fallback")
                return len(to_delete)
                
        except Exception as e:
            logger.error(f"Failed to cleanup old memories for user {user_id}: {e}")
            return 0
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get long-term memory statistics
        
        Returns:
            Dictionary with memory stats
        """
        try:
            if self.connection:
                cursor = self.connection.cursor()
                
                # Get memory counts by type
                cursor.execute("""
                    SELECT content_type, COUNT(*) as count, AVG(importance_score) as avg_importance
                    FROM long_term_memory 
                    GROUP BY content_type
                """)
                type_stats = cursor.fetchall()
                
                # Get total count
                cursor.execute("SELECT COUNT(*) FROM long_term_memory")
                total_count = cursor.fetchone()[0]
                
                cursor.close()
                
                return {
                    "type": "postgresql",
                    "connected": True,
                    "total_memories": total_count,
                    "by_type": {row[0]: {"count": row[1], "avg_importance": row[2]} for row in type_stats},
                    "embedding_dimension": self.embedding_dim
                }
            else:
                # Fallback stats
                type_counts = {}
                for memory in self.fallback_storage.values():
                    content_type = memory.content_type
                    if content_type not in type_counts:
                        type_counts[content_type] = {"count": 0, "total_importance": 0}
                    type_counts[content_type]["count"] += 1
                    type_counts[content_type]["total_importance"] += memory.importance_score
                
                # Calculate averages
                for stats in type_counts.values():
                    stats["avg_importance"] = stats["total_importance"] / stats["count"]
                    del stats["total_importance"]
                
                return {
                    "type": "fallback",
                    "connected": False,
                    "total_memories": len(self.fallback_storage),
                    "by_type": type_counts,
                    "embedding_dimension": self.embedding_dim
                }
                
        except Exception as e:
            logger.error(f"Failed to get memory stats: {e}")
            return {"type": "unknown", "error": str(e)}

    # Test interface compatibility methods
    async def store_knowledge(self, knowledge_data: Dict[str, Any]) -> bool:
        """Store knowledge data (test interface compatibility)"""
        try:
            memory_id = f"knowledge_{int(time.time())}_{knowledge_data.get('topic', 'unknown')}"
            memory_data = LongTermMemoryData(
                memory_id=memory_id,
                user_id=knowledge_data.get('user_id', 'test_user'),
                session_id=f"session_{int(time.time())}",
                content=knowledge_data.get('content', ''),
                content_type='knowledge',
                metadata={
                    'topic': knowledge_data.get('topic', ''),
                    'tags': knowledge_data.get('tags', [])
                },
                embedding=None,
                created_at=time.time(),
                accessed_at=time.time()
            )
            return self.store_memory(memory_data)
        except Exception as e:
            logger.error(f"Failed to store knowledge: {e}")
            return False

    async def semantic_search(self, query: str, limit: int = 5) -> List[Dict[str, Any]]:
        """Semantic search in long-term memory (test interface compatibility)"""
        try:
            # For test compatibility, return mock results based on fallback storage
            results = []
            search_terms = query.lower().split()
            
            for memory in list(self.fallback_storage.values())[:limit]:
                content_lower = memory.content.lower()
                similarity = sum(1 for term in search_terms if term in content_lower) / len(search_terms)
                
                if similarity > 0:
                    results.append({
                        'content': memory.content,
                        'similarity': similarity,
                        'tags': memory.metadata.get('tags', [])
                    })
            
            # Sort by similarity
            results.sort(key=lambda x: x['similarity'], reverse=True)
            return results[:limit]
            
        except Exception as e:
            logger.error(f"Failed to perform semantic search: {e}")
            return []

    async def store_user_preferences(self, preferences: Dict[str, Any]) -> bool:
        """Store user preferences (test interface compatibility)"""
        try:
            memory_id = f"prefs_{preferences.get('user_id', 'test_user')}_{int(time.time())}"
            memory_data = LongTermMemoryData(
                memory_id=memory_id,
                user_id=preferences.get('user_id', 'test_user'),
                session_id=f"session_{int(time.time())}",
                content=f"User preferences: {preferences}",
                content_type='preferences',
                metadata=preferences,
                embedding=None,
                created_at=time.time(),
                accessed_at=time.time()
            )
            return self.store_memory(memory_data)
        except Exception as e:
            logger.error(f"Failed to store user preferences: {e}")
            return False
