"""
Short-Term Memory Implementation  
Redis-based memory for session persistence and cross-conversation context
"""

import json
import time
import redis
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, asdict
import logging

logger = logging.getLogger(__name__)

@dataclass
class SessionMemory:
    """Data structure for session-based memory"""
    session_id: str
    user_id: str
    data: Dict[str, Any]
    created_at: float
    updated_at: float
    access_count: int = 0

class ShortTermMemory:
    """
    Redis-based short-term memory for session persistence
    Stores conversation context that persists across requests
    """
    
    def __init__(self, redis_url: str = "redis://localhost:6379/0", session_ttl: int = 3600):
        """
        Initialize short-term memory
        
        Args:
            redis_url: Redis connection URL
            session_ttl: Session time-to-live in seconds (default: 1 hour)
        """
        try:
            self.redis_client = redis.from_url(redis_url, decode_responses=True)
            self.session_ttl = session_ttl
            self.created_at = time.time()
            
            # Test connection
            self.redis_client.ping()
            logger.info("Short-term memory connected to Redis")
            
        except redis.ConnectionError:
            logger.warning("Redis not available, using fallback in-memory storage")
            self.redis_client = None
            self.fallback_storage: Dict[str, SessionMemory] = {}
    
    def _get_session_key(self, session_id: str, user_id: str) -> str:
        """Generate Redis key for session"""
        return f"session:{user_id}:{session_id}"
    
    def store_session(self, session_id: str, user_id: str, data: Dict[str, Any]) -> bool:
        """
        Store session data in short-term memory
        
        Args:
            session_id: Unique session identifier
            user_id: User identifier
            data: Session data to store
            
        Returns:
            True if stored successfully
        """
        try:
            current_time = time.time()
            session_memory = SessionMemory(
                session_id=session_id,
                user_id=user_id,
                data=data,
                created_at=current_time,
                updated_at=current_time,
                access_count=0
            )
            
            if self.redis_client:
                # Store in Redis
                key = self._get_session_key(session_id, user_id)
                session_json = json.dumps(asdict(session_memory))
                self.redis_client.setex(key, self.session_ttl, session_json)
                
                logger.debug(f"Stored session {session_id} for user {user_id} in Redis")
            else:
                # Fallback to in-memory storage
                key = self._get_session_key(session_id, user_id)
                self.fallback_storage[key] = session_memory
                
                logger.debug(f"Stored session {session_id} for user {user_id} in fallback storage")
            
            return True
            
        except Exception as e:
            logger.error(f"Failed to store session {session_id}: {e}")
            return False
    
    async def store_session_data(self, session_id: str, data: Dict[str, Any], ttl: int = None) -> bool:
        """Store session data (async test interface compatibility)"""
        import asyncio
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.store_session, session_id, "test_user", data)
    
    async def get_session_data(self, session_id: str) -> Optional[Dict[str, Any]]:
        """Get session data (async test interface compatibility)"""
        import asyncio
        loop = asyncio.get_event_loop()
        session = await loop.run_in_executor(None, self.retrieve_session, session_id, "test_user")
        return session.data if session else None
    
    def retrieve_session(self, session_id: str, user_id: str) -> Optional[SessionMemory]:
        """
        Retrieve session data from short-term memory
        
        Args:
            session_id: Session identifier
            user_id: User identifier
            
        Returns:
            SessionMemory object if found, None otherwise
        """
        try:
            key = self._get_session_key(session_id, user_id)
            
            if self.redis_client:
                # Retrieve from Redis
                session_json = self.redis_client.get(key)
                if session_json:
                    session_data = json.loads(session_json)
                    session_memory = SessionMemory(**session_data)
                    
                    # Update access count
                    session_memory.access_count += 1
                    session_memory.updated_at = time.time()
                    
                    # Store back with updated access count
                    updated_json = json.dumps(asdict(session_memory))
                    self.redis_client.setex(key, self.session_ttl, updated_json)
                    
                    logger.debug(f"Retrieved session {session_id} for user {user_id} from Redis")
                    return session_memory
            else:
                # Retrieve from fallback storage
                if key in self.fallback_storage:
                    session_memory = self.fallback_storage[key]
                    session_memory.access_count += 1
                    session_memory.updated_at = time.time()
                    
                    logger.debug(f"Retrieved session {session_id} for user {user_id} from fallback storage")
                    return session_memory
            
            return None
            
        except Exception as e:
            logger.error(f"Failed to retrieve session {session_id}: {e}")
            return None
    
    def update_session(self, session_id: str, user_id: str, data: Dict[str, Any]) -> bool:
        """
        Update existing session data
        
        Args:
            session_id: Session identifier
            user_id: User identifier
            data: Updated session data
            
        Returns:
            True if updated successfully
        """
        try:
            existing_session = self.retrieve_session(session_id, user_id)
            if existing_session:
                # Merge data
                existing_session.data.update(data)
                existing_session.updated_at = time.time()
                
                # Store updated session
                return self.store_session(session_id, user_id, existing_session.data)
            else:
                # Create new session if doesn't exist
                return self.store_session(session_id, user_id, data)
                
        except Exception as e:
            logger.error(f"Failed to update session {session_id}: {e}")
            return False
    
    def delete_session(self, session_id: str, user_id: str) -> bool:
        """
        Delete session from short-term memory
        
        Args:
            session_id: Session identifier
            user_id: User identifier
            
        Returns:
            True if deleted successfully
        """
        try:
            key = self._get_session_key(session_id, user_id)
            
            if self.redis_client:
                result = self.redis_client.delete(key)
                logger.debug(f"Deleted session {session_id} for user {user_id} from Redis")
                return result > 0
            else:
                if key in self.fallback_storage:
                    del self.fallback_storage[key]
                    logger.debug(f"Deleted session {session_id} for user {user_id} from fallback storage")
                    return True
                return False
                
        except Exception as e:
            logger.error(f"Failed to delete session {session_id}: {e}")
            return False
    
    def get_user_sessions(self, user_id: str) -> List[SessionMemory]:
        """
        Get all sessions for a specific user
        
        Args:
            user_id: User identifier
            
        Returns:
            List of SessionMemory objects
        """
        sessions = []
        try:
            if self.redis_client:
                # Find all session keys for the user
                pattern = f"session:{user_id}:*"
                keys = self.redis_client.keys(pattern)
                
                for key in keys:
                    session_json = self.redis_client.get(key)
                    if session_json:
                        session_data = json.loads(session_json)
                        sessions.append(SessionMemory(**session_data))
            else:
                # Search fallback storage
                for key, session_memory in self.fallback_storage.items():
                    if session_memory.user_id == user_id:
                        sessions.append(session_memory)
            
            logger.debug(f"Found {len(sessions)} sessions for user {user_id}")
            return sessions
            
        except Exception as e:
            logger.error(f"Failed to get sessions for user {user_id}: {e}")
            return []
    
    def cleanup_expired_sessions(self) -> int:
        """
        Clean up expired sessions (only needed for fallback storage)
        
        Returns:
            Number of sessions cleaned up
        """
        if self.redis_client:
            # Redis handles TTL automatically
            return 0
        
        # Cleanup fallback storage
        current_time = time.time()
        expired_keys = []
        
        for key, session_memory in self.fallback_storage.items():
            if current_time - session_memory.updated_at > self.session_ttl:
                expired_keys.append(key)
        
        for key in expired_keys:
            del self.fallback_storage[key]
        
        logger.info(f"Cleaned up {len(expired_keys)} expired sessions from fallback storage")
        return len(expired_keys)
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get memory statistics
        
        Returns:
            Dictionary with memory stats
        """
        try:
            if self.redis_client:
                info = self.redis_client.info()
                return {
                    "type": "redis",
                    "connected": True,
                    "memory_usage": info.get("used_memory_human", "unknown"),
                    "connected_clients": info.get("connected_clients", 0),
                    "uptime": info.get("uptime_in_seconds", 0)
                }
            else:
                return {
                    "type": "fallback",
                    "connected": False,
                    "session_count": len(self.fallback_storage),
                    "memory_usage": "in-process"
                }
                
        except Exception as e:
            logger.error(f"Failed to get memory stats: {e}")
            return {"type": "unknown", "error": str(e)}
