"""
Working Memory Implementation
Fast in-process memory for immediate conversation context
"""

import time
from typing import Dict, Any, Optional, List
from collections import OrderedDict
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

class WorkingMemory:
    """
    In-process working memory with LRU eviction
    Stores the most recent conversation context for immediate access
    """
    
    def __init__(self, max_size: int = 100):
        self.max_size = max_size
        self.memory: OrderedDict[str, Dict[str, Any]] = OrderedDict()
        self.cache = self.memory  # Interface compatibility for tests
        self.access_count = 0
        self.created_at = time.time()
    
    def store(self, key: str, data: Dict[str, Any]) -> bool:
        """
        Store data in working memory
        
        Args:
            key: Unique key for the data
            data: Data to store
            
        Returns:
            True if stored successfully
        """
        try:
            # Add timestamp
            data_with_timestamp = {
                **data,
                "_stored_at": time.time(),
                "_access_count": 0
            }
            
            # Remove if already exists (to update position)
            if key in self.memory:
                del self.memory[key]
            
            # Add to end (most recent)
            self.memory[key] = data_with_timestamp
            
            # Evict oldest if over limit
            while len(self.memory) > self.max_size:
                oldest_key = next(iter(self.memory))
                del self.memory[oldest_key]
                logger.debug(f"Evicted oldest item: {oldest_key}")
            
            logger.debug(f"Stored in working memory: {key}")
            return True
            
        except Exception as e:
            logger.error(f"Error storing in working memory: {e}")
            return False
    
    def store_context(self, session_id: str, context: 'ConversationContext') -> bool:
        """Store conversation context (test interface compatibility)"""
        return self.store(session_id, context.__dict__ if hasattr(context, '__dict__') else context)
    
    def get_context(self, session_id: str) -> Optional['ConversationContext']:
        """Get conversation context (test interface compatibility)"""
        data = self.retrieve(session_id)
        if data:
            # Try to reconstruct ConversationContext from dict
            try:
                return ConversationContext(**data)
            except Exception:
                return data  # Return raw data if reconstruction fails
        return None
    
    def retrieve(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Retrieve data from working memory
        
        Args:
            key: Key to retrieve
            
        Returns:
            Stored data or None if not found
        """
        try:
            if key not in self.memory:
                return None
            
            # Move to end (mark as recently accessed)
            data = self.memory.pop(key)
            data["_access_count"] = data.get("_access_count", 0) + 1
            data["_last_accessed"] = time.time()
            self.memory[key] = data
            
            self.access_count += 1
            logger.debug(f"Retrieved from working memory: {key}")
            
            # Return data without internal metadata
            return {k: v for k, v in data.items() if not k.startswith("_")}
            
        except Exception as e:
            logger.error(f"Error retrieving from working memory: {e}")
            return None
    
    def delete(self, key: str) -> bool:
        """Delete data from working memory"""
        try:
            if key in self.memory:
                del self.memory[key]
                logger.debug(f"Deleted from working memory: {key}")
                return True
            return False
        except Exception as e:
            logger.error(f"Error deleting from working memory: {e}")
            return False
    
    def list_keys(self) -> List[str]:
        """List all keys in working memory"""
        return list(self.memory.keys())
    
    def clear(self) -> bool:
        """Clear all data from working memory"""
        try:
            self.memory.clear()
            logger.info("Cleared working memory")
            return True
        except Exception as e:
            logger.error(f"Error clearing working memory: {e}")
            return False
    
    def get_stats(self) -> Dict[str, Any]:
        """Get working memory statistics"""
        total_size = sum(len(str(data)) for data in self.memory.values())
        
        return {
            "total_items": len(self.memory),
            "max_size": self.max_size,
            "utilization": len(self.memory) / self.max_size,
            "total_access_count": self.access_count,
            "estimated_size_bytes": total_size,
            "created_at": self.created_at,
            "age_seconds": time.time() - self.created_at
        }
    
    def get_recent_items(self, limit: int = 10) -> List[Dict[str, Any]]:
        """Get most recently accessed items"""
        recent_keys = list(self.memory.keys())[-limit:]
        return [
            {
                "key": key,
                "data": {k: v for k, v in self.memory[key].items() if not k.startswith("_")},
                "stored_at": self.memory[key].get("_stored_at"),
                "access_count": self.memory[key].get("_access_count", 0)
            }
            for key in recent_keys
        ]


@dataclass
class ConversationContext:
    """
    Context structure for conversation data in working memory
    """
    user_id: str
    session_id: str
    messages: List[Dict[str, Any]]
    current_topic: Optional[str] = None
    entities: List[str] = None
    sentiment: Optional[str] = None
    intent: Optional[str] = None
    metadata: Dict[str, Any] = None
    
    def __post_init__(self):
        if self.entities is None:
            self.entities = []
        if self.metadata is None:
            self.metadata = {}
    
    def add_message(self, role: str, content: str, metadata: Dict[str, Any] = None):
        """Add a message to the conversation context"""
        message = {
            "role": role,
            "content": content,
            "timestamp": time.time(),
            "metadata": metadata or {}
        }
        self.messages.append(message)
    
    def get_recent_messages(self, count: int = 5) -> List[Dict[str, Any]]:
        """Get the most recent messages"""
        return self.messages[-count:] if count > 0 else self.messages
    
    def get_message_history(self) -> str:
        """Get formatted message history as string"""
        history = []
        for msg in self.messages:
            history.append(f"{msg['role']}: {msg['content']}")
        return "\n".join(history)
    
    def update_topic(self, topic: str):
        """Update the current topic"""
        self.current_topic = topic
        self.metadata["last_topic_update"] = time.time()
    
    def add_entity(self, entity: str):
        """Add an entity to the context"""
        if entity not in self.entities:
            self.entities.append(entity)
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for storage"""
        return {
            "user_id": self.user_id,
            "session_id": self.session_id,
            "messages": self.messages,
            "current_topic": self.current_topic,
            "entities": self.entities,
            "sentiment": self.sentiment,
            "intent": self.intent,
            "metadata": self.metadata
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'ConversationContext':
        """Create from dictionary"""
        return cls(**data)
