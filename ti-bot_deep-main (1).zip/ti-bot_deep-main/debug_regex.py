#!/usr/bin/env python3
"""
Debug regex patterns to find the bad escape issue
"""

import re
import sys
from pathlib import Path

# Add project root to path
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from shared.rag.content_detector import ContentDetector

def test_regex_patterns():
    """Test all regex patterns for compilation errors"""
    detector = ContentDetector()
    
    test_content = "ERROR 2023-09-21: Database connection failed - Connection timeout after 30 seconds"
    
    print("🔍 Testing regex patterns...")
    
    # Test each pattern set
    pattern_sets = [
        ("code_patterns", detector.code_patterns),
        ("error_patterns", detector.error_patterns),
        ("config_patterns", detector.config_patterns),
        ("log_patterns", detector.log_patterns),
        ("documentation_patterns", detector.documentation_patterns),
        ("query_patterns", detector.query_patterns)
    ]
    
    for name, patterns in pattern_sets:
        print(f"\n📋 Testing {name}:")
        for i, pattern in enumerate(patterns):
            try:
                compiled = re.compile(pattern, re.IGNORECASE | re.MULTILINE)
                matches = compiled.findall(test_content)
                print(f"  ✅ Pattern {i+1}: {pattern[:30]}... - {len(matches)} matches")
            except Exception as e:
                print(f"  ❌ Pattern {i+1}: {pattern} - ERROR: {e}")
    
    # Test content detection
    print(f"\n🧪 Testing content detection on: {test_content}")
    try:
        result = detector.detect_content_type(test_content)
        print(f"✅ Result: {result}")
    except Exception as e:
        print(f"❌ Detection failed: {e}")

if __name__ == "__main__":
    test_regex_patterns()
